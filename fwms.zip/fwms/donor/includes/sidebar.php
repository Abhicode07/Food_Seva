<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="dashboard.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
               

<li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-th"></i>
                        <span>List Your Food Detail</span>
                    </a>
                    <ul class="sub">
                        <li><a href="add-food-details.php">Add Food</a></li>
                        <li><a href="manage-food-details.php">Manage Food</a></li>
                    </ul>
                </li>

        <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-files-o"></i>
                        <span>Requests</span>
                    </a>
                    <ul class="sub">
                        <li><a href="new-requests.php">New</a></li>
                        <li><a href="completed-requests.php">Picked/Completed</a></li>
                          <li><a href="rejected-requests.php">Rejected</a></li>
                           <li><a href="all-requests.php">All</a></li>
                    </ul>
                </li>
                                
                             
                         <li>
                    <a class="active" href="search.php">
                        <i class="fa fa-search"></i>
                        <span>Search</span>
                    </a>
                </li>
              
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>